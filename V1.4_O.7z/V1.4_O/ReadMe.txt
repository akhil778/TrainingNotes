1. Change Employee Id in TodaysSwipes.vbs
2. Run RunAWH.vbs
3. Give LAN password If required.

Note: Don't keep in folder named with 'spaces'